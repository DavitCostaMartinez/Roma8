export const getIncident = (state) => {
    return state.incident
}

export const getIncidents = (state) => {
    return state.incidents
}

