export default () => ({ //Lo que hace es una funcion reactiva y devuelve un objeto que sea reactivo
    incident: {},
    incidents: [],
})