export const getSuggestion = (state) => {
    return state.suggestion
}

export const getSuggestions = (state) => {
    return state.suggestions
}

