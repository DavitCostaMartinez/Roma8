export const getNews = (state) => {
    return state.news
}