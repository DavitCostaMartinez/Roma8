<template>
  <q-layout view="lHh Lpr lFf">
    <q-header class="header-container">
      <q-toolbar
        class="q-pa-sm q-gutter-x-md justify-content-between align-items-center"
      >
        <q-btn
          flat
          dense
          round
          class="q-ml-md"
          icon="menu"
          aria-label="Menu"
          @click="toggleLeftDrawer"
        />
        <q-space />
        <div class="header-buttons d-flex justify-content-end">
          <button @click="onProfile" :style="{ backgroundColor: userColors?.Botones?.color}" class="material-icons profile-button">
            account_circle
          </button>
          <button
            v-if="rolDB.admin"
            @click="onAdmin"
            class="material-icons shield-person"
            :style="{ backgroundColor: userColors?.Botones?.color}" 
          >
            admin_panel_settings
          </button>
          <button @click="onLogout" :style="{ backgroundColor: userColors?.Botones?.color}"  class="material-icons logout-button">
            exit_to_app
          </button>
        </div>
      </q-toolbar>
      <div class="q-px-lg q-mb-md">
        <q-toolbar-title> Bienvenido, {{ username }} </q-toolbar-title>
      </div>
      <q-img
        src="../assets/building.jpg"
        class="header-image absolute-top"
      ></q-img>
    </q-header>
    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <q-scroll-area
        style="
          height: calc(100% - 150px);
          margin-top: 150px;
          border-right: 1px solid #ddd;
        "
        
      >
        <q-list >
          <EssentialLink
            v-for="link in linksList"
            :key="link.title"
            v-bind="link"
          />
        </q-list>
      </q-scroll-area>
      <q-img
        class="absolute-top"
        :src="userColors?.fondo?.color"
        style="height: 150px"
      >
        <div class="absolute-bottom bg-transparent">
          <q-avatar size="56px" class="q-mb-sm">
            <img :src="user.photo" />
          </q-avatar>
          <div class="text-weight-bold">{{ user.name }} {{ user.surname }}</div>
          <div>{{ user.email }}</div>
        </div>
      </q-img>
    </q-drawer>
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { defineComponent, ref, onMounted, computed, watch } from "vue";
import { linksList } from "../router/links-list";
import EssentialLink from "components/EssentialLink.vue";
import useAuth from "src/modules/auth/composables/useAuth";
import { useRouter } from "vue-router";
import { useStore } from "vuex";

export default defineComponent({
  name: "MainLayout",

  components: {
    EssentialLink,
  },
  setup() {
    const store = useStore();
    const leftDrawerOpen = ref(false);
    const user = ref({});
    const { username, logout, loadUsersById } = useAuth();
    const router = useRouter();
    const routeParams = router.currentRoute.value.params;
    const userId = routeParams.id;
    const rolDB = ref({});
    const conff = ref({});
    const primaryColor = computed(() => userColors.value?.Diseño?.color);
    const userColors = computed(
      () => store.getters["authModule/getUserColors"]
    );

    const onLogout = () => {
      router.push({ name: "login-screen" });
      logout();
    };

    const loadUserInfo = async () => {
      try {
        const userData = await loadUsersById(userId);
        user.value = userData;
        const rol = computed(() => store.getters["authModule/getRolDB"]);
        rolDB.value = rol.value;
        const conf = computed(() => store.getters["authModule/getConf"]);
        conff.value = conf.value;
      } catch (error) {
        console.error("Error al cargar la información del usuario:", error);
      }
    };

    const conf = computed(() => store.getters["authModule/getConf"]);

    // Función para filtrar los enlaces activos
    const filteredLinks = computed(() => {
      return linksList.filter((link) => {
        // Utiliza el nombre del enlace para buscar el estado correspondiente en la configuración
        return conf.value[link.title.toLowerCase()].activo;
      });
    });

    const fetchColorsFromDatabase = async () => {
      try {
       await store.dispatch('authModule/getColorsFromDatabase');
      } catch (error) {
        console.error('Error al recuperar los colores de la base de datos:', error);
      }
    };

    const injectStyles = () => {
      const styleElement = document.createElement('style');
      styleElement.innerHTML = `:root { --q-primary: ${primaryColor.value}; }`;
      document.head.appendChild(styleElement);
    };
    injectStyles()

 const saveColorsToLocalStorage = () => {
      localStorage.setItem('userColors', JSON.stringify(userColors.value));
    };

    // Función para cargar los colores desde localStorage al iniciar
    const loadColorsFromLocalStorage = () => {
      const savedColors = localStorage.getItem('userColors');

    };

    // Guardar los colores en localStorage al cambiar
    watch(userColors, () => {
      saveColorsToLocalStorage();
      injectStyles();
    }, );

    const onProfile = () => {
      router.push({
        name: "profile-page",
        params: {
          id: userId,
        },
      });
    };

    const onAdmin = () => {
      router.push({
        name: "admin-page",
        params: {
          id: userId,
        },
      });
    };

    onMounted(() => {
      loadUserInfo();
      fetchColorsFromDatabase();
      console.log("diamantes",userColors?.value.fondo?.color)
      loadColorsFromLocalStorage();
    });

    return {
      user,
      linksList,
      leftDrawerOpen,
      toggleLeftDrawer() {
        leftDrawerOpen.value = !leftDrawerOpen.value;
      },
      username,
      loadUsersById,
      onLogout,
      onAdmin,
      onProfile,
      rolDB,
      filteredLinks,
      userColors,
    };
  },
});
</script>

<style lang="css" scoped>
.header-container {
  display: flex;
  flex-wrap: wrap;
}

.header-buttons {
  display: flex;
}

.material-icons {
  border: none;
  border-radius: 10px;
  color: black;
  cursor: pointer;
  font-size: 37px;
  padding: 9px;
  transition: all 0.3s ease;
}

.material-icons:hover {
  background-color: #17a2b8 !important;
  color: white;
}

.header-image {
  height: 100%;
  z-index: -1;
  opacity: 0.2;
  filter: grayscale(100%);
}
</style>