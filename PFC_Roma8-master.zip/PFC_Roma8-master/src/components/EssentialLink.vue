
<template>
  <div>
    <div v-for="key in Object.keys(conff)" :key="key">
      <div v-if="key === title">
        <q-item 
          class="menu"
          :class="{ 'active-menu': isActiveRoute(link) }"
          clickable 
          @click="navigateTo" 
          v-if="conff[key].activo" 
          :style="{ backgroundColor: userColors?.Botones?.color, border: 'solid 1px ' + userColors?.Lista?.color }"
          text-color="black"             
          label
        >
          <q-item-section v-if="icon" avatar>
            <q-icon :name="icon" />
          </q-item-section>

          <q-item-section>
            <q-item-label>
              <!-- Utiliza clases de Quasar para personalizar el color de fondo y el texto del botón -->
              {{ title }}
            </q-item-label>
          </q-item-section>
        </q-item>
      </div>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref, onMounted, computed } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";

export default defineComponent({
  name: "EssentialLink",
  props: {
    title: {
      type: String,
      required: true,
    },

    caption: {
      type: String,
      default: "",
    },

    link: {
      type: String,
      default: "#",
    },

    icon: {
      type: String,
      default: "",
    },
  },
  setup(props) {
    const router = useRouter();
    const conff=ref({});
    const store = useStore();

      const cargarConfiguracion = async () => {
       let co= await store.dispatch('authModule/loadConfiguration');

       conff.value=co
    };
    const userColors = computed(
      () => store.getters["authModule/getUserColors"]
    );

    const isActiveRoute = (routeTitle) => {
      return router.currentRoute.value.name === routeTitle;
      
    };
    onMounted(() => {
      cargarConfiguracion();

    });

    return {
      navigateTo() {
        if (props.link.startsWith("http")) {
          window.open(props.link, "_blank");
        } else {
          router.push({ name: props.link });
        }
      },
      conff,
      userColors,
      isActiveRoute,
    };
  },
});
</script>

<style scoped>
.menu:hover{
  background-color: white !important;
  color: black
}
.active-menu {
  background-color: white !important;
}
</style>