// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from 'firebase/firestore/lite';
import firebase from 'firebase/compat/app';
import 'firebase/compat/storage';

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCnDKQ0M4rP_r5oX8oMp0vTcCDbOC2rGHs",
    authDomain: "roma8-4d32f.firebaseapp.com",
    databaseURL: "https://roma8-4d32f-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "roma8-4d32f",
    storageBucket: "roma8-4d32f.appspot.com",
    messagingSenderId: "150417604885",
    appId: "1:150417604885:web:27a60535902bdd45c3a91c"
  };  

firebase.initializeApp(firebaseConfig);
let storage = firebase.storage();

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db, storage };