import axios from 'axios';

const roma8Api = axios.create({
    baseURL: 'https://roma8-4d32f-default-rtdb.europe-west1.firebasedatabase.app/'

})

roma8Api.interceptors.request.use((config) => {

    config.params = {
        auth: localStorage.getItem('idToken')
    }
    return config
})

export default roma8Api