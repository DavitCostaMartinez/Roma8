import axios from 'axios';

const authApi = axios.create({
    baseURL: 'https://identitytoolkit.googleapis.com/v1/accounts',
    params: {
        key: 'AIzaSyCnDKQ0M4rP_r5oX8oMp0vTcCDbOC2rGHs'
    }
})

export default authApi