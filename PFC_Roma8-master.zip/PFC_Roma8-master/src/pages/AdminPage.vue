<template>
  <div class="profile-list-container">
    <div class="button-grid">
      <div class="button-container">
        <button
          :style="{ backgroundColor: userColors?.Botones?.color }"
          @click="onVivienda"
          class="large-button"
        >
          Vivienda
        </button>
      </div>
      <!--
<button v-if="rolDB?.noticias?.leer" @click="onVivienda">
  Vivienda
</button>
-->
      <div class="button-container">
        <button  :style="{ backgroundColor: userColors?.Botones?.color }" @click="onActas" class="large-button">Actas</button>
      </div>
      <div class="button-container">
        <button  :style="{ backgroundColor: userColors?.Botones?.color }" @click="onRol" class="large-button">Roles</button>
      </div>
      <div class="button-container">
        <button  :style="{ backgroundColor: userColors?.Botones?.color }" @click="onConf" class="large-button">Configuración</button>
      </div>
      <div class="button-container">
        <button  :style="{ backgroundColor: userColors?.Botones?.color }" @click="onEspacio" class="large-button">Espacio</button>
      </div>
      <div class="button-container">
        <button  :style="{ backgroundColor: userColors?.Botones?.color }" @click="onTema" class="large-button">Tema</button>
      </div>
    </div>
  </div>
</template>

<script>
import { computed } from "vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";

export default {
  name: "AdminPage",

  setup() {
    const router = useRouter();
    const store = useStore();

    const userColors = computed(
      () => store.getters["authModule/getUserColors"]
    );
    const rolDB = computed(() => store.getters["authModule/getRolDB"]);

    const onVivienda = () => {
      router.push({ name: "admin-vivienda" });
    };

    const onActas = () => {
      router.push({ name: "admin-actas" });
    };
    const onRol = () => {
      router.push({ name: "admin-rol" });
    };

    const onConf = () => {
      router.push({ name: "admin-conf" });
    };
    const onEspacio = () => {
      router.push({ name: "admin-espacio" });
    };

    const onTema = () => {
      router.push({ name: "admin-tema" });
    };

    return {
      onVivienda,
      onActas,
      onRol,
      onConf,
      onEspacio,
      onTema,
      userColors,
    };
  },
};
</script>

<style scoped>
.profile-list-container {
  text-align: center;
}

.button-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.button-container {
  display: flex;
  justify-content: center;
}

.large-button {
  width: 150px;
  height: 60px;
  font-size: 1.2rem;
  margin-top:15px;
}
</style>