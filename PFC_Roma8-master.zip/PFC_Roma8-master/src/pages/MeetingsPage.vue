<template>
  <q-page class="flex">
    <h1>Meetings.vue</h1>
  </q-page>
</template>
  
  <script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "MeetingsPage",
});
</script>
  