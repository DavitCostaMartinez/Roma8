<template>
  <q-page class="q-pa-md">
    <div class="q-gutter-md">
      <q-card class="q-mb-md" :style="{ border: 'solid 3px ' + userColors?.Lista?.color }">
        <q-card-section>
          <h2 class="text-h6">Crear Usuario</h2>
        </q-card-section>

        <q-card-section>
          <!-- Nombre de Usuario -->
          <q-input
            v-model="newUser.name"
            label="Nombre de Usuario"
            outlined
          />

          <!-- Apellidos -->
          <q-input v-model="newUser.surname" label="Apellidos" outlined />

          <!-- Rol (Seleccionar vacío por ahora) -->
          <q-select
            v-model="selectedRole"
            :options="roles"
            label="Rol"
            outlined
          />

          <!-- Teléfono -->
          <q-input v-model="newUser.phone" label="Teléfono" outlined />

          <!-- Número de Puerta -->
          <q-input
            v-model="newUser.n_door"
            label="Número de Puerta"
            outlined
          />

          <!-- Escalera -->
          <q-input v-model="newUser.stair" label="Escalera" outlined />

          <!-- Piso -->
          <q-input v-model="newUser.floor" label="Piso" outlined />

          <!-- Correo Electrónico -->
          <q-input
            v-model="newUser.email"
            label="Correo Electrónico"
            outlined
          />

          <!-- Contraseña -->
          <q-input
            v-model="newUser.password"
            label="Contraseña"
            type="password"
            outlined
          />

          <!-- Checkbox Admin de Finca -->
          <q-checkbox
            v-model="newUser.adminproperty"
            label="Admin de Finca"
          />

          <!-- Botón para crear el usuario -->
          <div class="q-gutter-md">
            <q-btn-group>
              <q-btn
                :style="{ backgroundColor: userColors?.Botones?.color }"
                label="Crear Usuario"
                @click="createUser"
              />
              <q-btn
                color="negative"
                label="Cancelar"
                @click="cancelForm"
              />
            </q-btn-group>
          </div>
        </q-card-section>
      </q-card>

      <div class="users-list">
        <h2 class="text-h6">Lista de Usuarios</h2>
        <div v-for="(user, index) in users" :key="index" class="user">
          <div class="user-info">
            <div class="user-details">
              <h3>{{ user.name }} {{ user.surname }}</h3>
              <p><strong>Rol:</strong> {{ user.role }}</p>
              <p><strong>Email:</strong> {{ user.email }}</p>
              <p><strong>Teléfono:</strong> {{ user.phone }}</p>
              <p><strong>Número de Puerta:</strong> {{ user.n_door }}</p>
              <p><strong>Escalera:</strong> {{ user.stair }}</p>
              <p><strong>Piso:</strong> {{ user.floor }}</p>
              <p><strong>Admin de Finca:</strong> {{ user.adminproperty ? 'Sí' : 'No' }}</p>

            </div>
            <div class="user-actions">
              <q-btn :style="{ backgroundColor: userColors?.Botones?.color }" label="Editar" @click="editUser(user)" />
              <q-btn color="negative" label="Eliminar" @click="deleteUser(index)" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </q-page>
</template>


<script>
import { ref, onMounted, computed } from "vue";
import { useStore } from "vuex";
import CryptoJS from "crypto-js";

export default {
  name: "AdminHousing",
  setup() {
    // Variables for form fields
    const roles = ref([]);
    const selectedRole = ref("");
    const newUser = ref({
      name: "",
      surname: "",
      role: selectedRole,
      phone: "",
      n_door: "",
      stair: "",
      floor: "",
      email: "",
      password: "",
      adminproperty: false,
      photo: "https://firebasestorage.googleapis.com/v0/b/roma8-4d32f.appspot.com/o/imagenes%2Fdefault.png?alt=media&token=65549a7b-c886-4d24-bdb8-451485cfa9e7",
    });

    const users = ref([]);
            const userColors = computed(
      () => store.getters["authModule/getUserColors"]
    );
    // Reference to Vuex store
    const store = useStore();

    // Function to get roles from Firebase API
    const getRoles = async () => {
      try {
        const rolesFromAPI = await store.dispatch(
          "authModule/getRolesFromDatabase"
        );
        if (rolesFromAPI && typeof rolesFromAPI === "object") {
          roles.value = Object.keys(rolesFromAPI);
        } else {
          console.error(
            "API response is not in the expected format"
          );
        }
      } catch (error) {
        console.error("Error getting roles:", error);
      }
    };

    // Call getRoles function when the component mounts
    onMounted(() => {
      getRoles();
      getUsers();
    });

    // Function to get users from database
    const getUsers = async () => {
      users.value = await store.dispatch("authModule/getUsersFromDatabase");
      console.log(Object.keys(users.value))
      console.log(users.value)
    };

    // Function to delete a user
    const deleteUser = async (userId) => {
      try {
        await store.dispatch("authModule/deleteUser", userId);
        // After deletion, update the user list
        await getUsers();
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    };

    // Function to edit a user
    const editUser = (user) => {
      // Implement your logic to edit a user here
    };

    const auth = ref({
      email: newUser.value.email,
      password: newUser.value.password,
    });

    // Function to create a new user
    const createUser = async () => {
      try {
        auth.value.email = newUser.value.email;
        auth.value.password = newUser.value.password;
        const md5Password = CryptoJS.MD5(
          newUser.value.password
        ).toString();
        // Assign the hashed password to the newUser object
        newUser.value.password = md5Password;
        // Call the 'createUser' action from Vuex store and pass the newUser object as an argument
        
        await store.dispatch("authModule/createUser2", {
          user: newUser.value,
          auth: auth.value,
        });
        
        // Clear the form fields after creating the user
       //window.location.reload();
             newUser.value = {
        name: "",
        surname: "",
        role: "",
        phone: "",
        n_door: "",
        stair: "",
        floor: "",
        email: "",
        password: "",
        adminproperty: false,
      };
      const user=computed(() => store.getters["authModule/getUsuarios"]);
      console.log(user.value)
      users.value=user.value
      } catch (error) {
        console.error("Error creating user:", error);
        // Handle the error as per your requirement
      }
    };

    // Function to clear the form fields
    const cancelForm = () => {
      newUser.value = {
        name: "",
        surname: "",
        role: "",
        phone: "",
        n_door: "",
        stair: "",
        floor: "",
        email: "",
        password: "",
        adminproperty: false,
      };
    };

    return {
      // Variables
      newUser,
      // Functions
      createUser,
      // Other necessary data
      roles,
      selectedRole,
      cancelForm,
      auth,
      users,
      deleteUser,
      editUser,
      userColors
    };
  },
};
</script>

<style>
/* Add your styles here */
</style>
