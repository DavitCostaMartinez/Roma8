<template>
  <q-page class="flex">
    <h1>Votations.vue</h1>
  </q-page>
</template>
  
  <script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "VotationsPage",
});
</script>
  