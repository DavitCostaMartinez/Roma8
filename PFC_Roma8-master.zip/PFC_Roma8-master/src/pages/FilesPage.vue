<template>
  <q-page class="flex">
    <h1>Files.vue</h1>
  </q-page>
</template>
  
  <script>
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'FilesPage',
});
</script>
  