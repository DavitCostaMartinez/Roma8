<template>
  <div class="profile-list-container">
    <h1>Bienvenido a las Actas</h1>

    <!-- Input de tipo file para seleccionar el archivo PDF -->
    <input type="file"  @change="handleFileChange" accept="application/pdf">

    <!-- Botón para guardar -->
    <q-btn @click="saveActas" color="primary">Guardar</q-btn>
  </div>
</template>

<script>
import { ref } from 'vue';

export default {
  name: "AdminActas",

  setup() {
    // Referencia al input de tipo file
    const fileInputRef = ref(null);
    // Variable para almacenar el archivo PDF seleccionado
    const selectedPDF = ref(null);

    // Método para manejar el cambio en el input de tipo file
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        selectedPDF.value = file;
    };

    // Método para manejar el guardado de actas
    const saveActas = () => {
      console.log("Archivo PDF seleccionado:", selectedPDF.value);
      if (fileInputRef.value) {
        fileInputRef.value.value = "";
      }
    };

    return {
      fileInputRef,
      selectedPDF,
      handleFileChange,
      saveActas,
    };
  },
};
</script>

<style scoped>
/* Estilos específicos para este componente */
</style>
