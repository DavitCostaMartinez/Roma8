<template>
  <div class="q-pa-md">
    <template v-if="news.length > 0">
      <q-infinite-scroll @load="onLoad" :offset="250">
        <div
          v-for="(item, index) in news"
          :key="index"
          class="q-pa-md row items-start q-gutter-md d-flex justify-center"
        >
          <q-card class="col-12 col-sm-12 col-md-7"
          :style="{ border: 'solid 3px ' + userColors?.Lista?.color }"
           bordered>
            <q-img :src="item.photo" />
            <q-card-section>
              <div class="text-overline text-orange-9">
                {{ formatDateShort(item.date) }}
              </div>
              <div
                class="text-h5 q-mt-sm q-mb-xs"
                style="overflow-wrap: break-word"
              >
                {{ item.title }}
              </div>
              <br />
              <div
                class="text-caption text-grey"
                style="overflow-wrap: break-word"
              >
                {{ item.description }}
              </div>
            </q-card-section>
            <q-card-actions>
              <q-btn
                v-if="rolDB?.noticias?.eliminar"
                color="green"
                round
                flat
                icon="delete"
                @click="openCard(item.id, item.photo)"
              />
              <q-dialog v-model="confirm" persistent>
                <q-card>
                  <q-card-section class="row items-center">
                    <span class="q-ml-sm"
                      >¿Estás seguro que desea eliminar esta noticia?</span
                    >
                  </q-card-section>
                  <q-card-actions align="right">
                    <q-btn
                      flat
                      label="Cancelar"
                      color="primary"
                      v-close-popup
                    />
                    <q-btn
                      flat
                      label="Eliminar"
                      color="primary"
                      @click="deleteNewscastInfo"
                      v-close-popup
                    />
                  </q-card-actions>
                </q-card>
              </q-dialog>
            </q-card-actions>
          </q-card>
        </div>
      </q-infinite-scroll>
      <q-page-sticky position="bottom-right" :offset="[18, 18]">
        <q-btn
          @click="$router.push({ name: 'news-page' })"
          v-if="rolDB?.noticias?.crear"
          fab
          icon="add"
          :style="{ backgroundColor: userColors?.Botones?.color }"
        />
      </q-page-sticky>
    </template>
    <template v-else>
      <div>
        <h2>No hay noticias en este momento</h2>
        <q-page-sticky position="bottom-right" :offset="[18, 18]">
          <q-btn
            @click="$router.push({ name: 'news-page' })"
            v-if="rolDB?.noticias?.crear"
            fab
            icon="add"
            :style="{ backgroundColor: userColors?.Botones?.color }"
          />
        </q-page-sticky>
      </div>
      <router-view />
    </template>
  </div>
</template>

<script>
import { ref, computed, onMounted } from "vue";
import { useStore } from "vuex";
import useNews from "src/modules/news/composables/useNews";
import { storage } from "../boot/firebase";

export default {
  setup() {
    const store = useStore();
    const news = ref([]);
    const rolDB = computed(() => store.getters["authModule/getRolDB"]);
    const { loadNewsDB, deleteNewscastDBAndState } = useNews();
    const selectedId = ref(null);
    const confirm = ref(false);
    const urlPhoto = ref("");
    let storageRef = storage.ref();
        const userColors = computed(
      () => store.getters["authModule/getUserColors"]
    );

    const loadNewsInfo = async () => {
      const newsDB = await loadNewsDB();

      if (newsDB && newsDB.length > 0) {
        news.value = newsDB.sort((a, b) => {
          const dateA = new Date(a.date);
          const dateB = new Date(b.date);
          return dateB - dateA;
        });
      } else {
        news.value = [];
      }
    };

    const deleteNewscastInfo = async () => {
      await deleteNewscastDBAndState(selectedId.value);

      const decodedUrl = decodeURIComponent(urlPhoto.value);
      const lastIndex = decodedUrl.lastIndexOf("/");
      const nombreArchivoConParametros = decodedUrl.substring(lastIndex + 1);
      const nombreArchivoSinParametros =
        nombreArchivoConParametros.split("?")[0];
      console.log(nombreArchivoSinParametros);

      const desertRef = storageRef.child(
        `noticias/${nombreArchivoSinParametros}`
      );

      await desertRef
        .delete()
        .then(() => {
          console.log("Archivo eliminado");
        })
        .catch((error) => {
          console.error("Error:", error);
        });

      await loadNewsInfo();
    };

    const openCard = async (id, photo) => {
      confirm.value = true;
      selectedId.value = id;
      urlPhoto.value = photo;
    };

    onMounted(() => {
      loadNewsInfo();
    });

    const formatDateShort = (dateNewscast) => {
      const date = new Date(dateNewscast);
      return date.toLocaleString();
    };

    return {
      expanded: ref(false),
      rolDB,
      news,
      formatDateShort,
      confirm,
      deleteNewscastInfo,
      openCard,
      userColors,
    };
  },
};
</script>

<style scoped>
.my-card {
  width: 80%;
}
</style>